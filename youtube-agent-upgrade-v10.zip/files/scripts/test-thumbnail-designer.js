/**
 * Thumbnail designer test.
 *   node scripts/test-thumbnail-designer.js
 * - Always: loads module, prints font resolution, runs design planning for several topics,
 *   renders all design families on SYNTHETIC placeholder backgrounds (NOT AI images) to test layout.
 * - If CLOUDFLARE_API_TOKEN + CLOUDFLARE_ACCOUNT_ID are set: runs a REAL end-to-end generation (3 FLUX images).
 * - Otherwise: runs the local-footage fallback if footage exists (or generates tiny test footage with ffmpeg).
 * Output goes to uploads/thumbnails/test-run-<timestamp>/ (contact sheet: _contact-sheet.jpg)
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const sharp = require('sharp');
const { spawnSync } = require('child_process');
const { ThumbnailDesignerAgent, DESIGN_FAMILIES } = require('../agents/thumbnail-designer-agent');

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
let failures = 0;
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) failures++; };

async function placeholderBackground(file, i) {
  const hues = [['#2b1d3a', '#7a3b4a'], ['#10243a', '#2f6f7a'], ['#2a2a2a', '#8a6a3a'], ['#1b1030', '#4a3a8a']];
  const [c1, c2] = hues[i % hues.length];
  const svg = `<svg width="1280" height="720" xmlns="http://www.w3.org/2000/svg"><defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient>
    <radialGradient id="s"><stop offset="0" stop-color="#e2b79a"/><stop offset="1" stop-color="#b98466"/></radialGradient></defs>
    <rect width="1280" height="720" fill="url(#g)"/>
    <ellipse cx="900" cy="640" rx="300" ry="250" fill="#20242c"/>
    <ellipse cx="900" cy="330" rx="150" ry="195" fill="url(#s)"/>
    <ellipse cx="850" cy="300" rx="22" ry="12" fill="#222"/><ellipse cx="950" cy="300" rx="22" ry="12" fill="#222"/>
    <rect x="860" y="400" width="80" height="10" rx="5" fill="#8a4a4a"/></svg>`;
  await sharp(Buffer.from(svg)).png().toFile(file);
}

(async () => {
  const outDir = path.join(__dirname, '..', 'uploads', 'thumbnails', 'test-run-' + stamp);
  fs.mkdirSync(outDir, { recursive: true });

  const agent = new ThumbnailDesignerAgent(null, {});
  await agent.initialize();
  ok(DESIGN_FAMILIES.length >= 12, `design families available: ${DESIGN_FAMILIES.length}`);
  console.log('Fonts:', JSON.stringify(agent.getFontReport(), null, 1));

  // 1) Planning variety across different videos
  const videos = [
    { title: '7 Signs You Are Being Gaslighted', script: 'Gaslighting makes you doubt your memory. Signs of gaslighting include denial, rewriting events and blaming you.' },
    { title: 'How Narcissists Use Charm As A Weapon' },
    { title: 'Body Language Secrets Of Liars', keywords: ['eye contact', 'micro expressions'] },
    { title: 'Why Your Boss Plays Mind Games At Work' },
    { title: 'Confirmation Bias: How Your Brain Fools You' },
    { title: 'The Psychology Of Peer Pressure' }
  ];
  const seenTrios = new Set();
  for (const v of videos) {
    const concept = await agent.generateConcept(v);
    const trio = concept.variantPlans.map(p => p.familyId).join('+');
    seenTrios.add(trio);
    console.log(`\n${v.title}\n  topic=${concept.analysis.topicId} emotion=${concept.analysis.emotionalAngle}`);
    concept.variantPlans.forEach(p => console.log(`  ${p.label} | "${p.headline}" (${p.headlineType}) | scene: ${p.scene.subject.slice(0, 60)}...`));
    ok(new Set(concept.variantPlans.map(p => p.familyId)).size === 3, 'three distinct families for: ' + v.title);
    ok(new Set(concept.variantPlans.map(p => p.headline)).size === 3, 'three distinct headlines for: ' + v.title);
    ok(concept.variantPlans.every(p => p.headline.replace(/[^\w ]/g, '') !== v.title.toUpperCase().replace(/[^\w ]/g, '')), 'headline != title');
    ok(concept.variantPlans.every(p => p.headline.split(/\s+/).length <= 6), 'headline <= 6 words');
    const prompt = agent.buildImagePrompt(concept, concept.variantPlans[0], 1);
    ok(prompt.length < 2000 && !/\b(text|letters|words|caption|logo|watermark)\b/i.test(prompt.replace(/wordless/gi, '')), 'prompt has no text-generation request, length ' + prompt.length);
  }
  ok(seenTrios.size >= 4, `different videos get different design trios (${seenTrios.size}/${videos.length})`);

  // 2) Render EVERY family on a synthetic placeholder background (layout/typography test only)
  const sheetFiles = [];
  for (let i = 0; i < DESIGN_FAMILIES.length; i++) {
    const fam = DESIGN_FAMILIES[i];
    const bg = path.join(outDir, `.bg_${i}.png`);
    await placeholderBackground(bg, i);
    const headline = ['WHO PULLS YOUR STRINGS?', 'THE QUIET RED FLAGS', 'THEY REWRITE YOUR MEMORY'][i % 3];
    try {
      const composed = await agent.composeCloudflareThumbnail(bg, headline, 'editorial-left', 'test' + i, agent.getTopicProfile({ title: 'manipulation' }), fam.id, { plan: { paletteIdx: i % 2, badge: 'WATCH CLOSELY' }, title: 'test' });
      const dest = path.join(outDir, `family-${String(i + 1).padStart(2, '0')}-${fam.id}.jpg`);
      fs.copyFileSync(composed.path, dest); fs.unlinkSync(composed.path);
      const q = composed.qualityChecks;
      ok(q.valid, `${fam.id}: ${composed.dimensions.width}x${composed.dimensions.height}, ${(composed.fileSize / 1024).toFixed(0)}KB, fit=${q.textFit}, contrast=${q.contrastRatio}${composed.layout.autoPanelAdded ? ' (auto panel)' : ''}, minFont=${q.minFontSize}, fonts=${composed.layout.fontsUsed.join('/')}` + (q.problems.length ? ' PROBLEMS: ' + q.problems : ''));
      sheetFiles.push(dest);
    } catch (e) { ok(false, `${fam.id}: ${e.message}`); }
    fs.unlinkSync(bg);
  }
  if (sheetFiles.length) {
    const cols = 3, tw = 640, th = 360, rows = Math.ceil(sheetFiles.length / cols);
    const comps = [];
    for (let i = 0; i < sheetFiles.length; i++) comps.push({ input: await sharp(sheetFiles[i]).resize(tw, th).toBuffer(), left: (i % cols) * tw, top: Math.floor(i / cols) * th });
    await sharp({ create: { width: cols * tw, height: rows * th, channels: 3, background: '#000' } }).composite(comps).jpeg({ quality: 85 }).toFile(path.join(outDir, '_contact-sheet.jpg'));
    console.log('Contact sheet:', path.join(outDir, '_contact-sheet.jpg'));
  }

  // 3) End-to-end generation
  const hasCf = process.env.CLOUDFLARE_API_TOKEN && process.env.CLOUDFLARE_ACCOUNT_ID;
  let tmpWorkspace = null;
  if (!hasCf) {
    const existing = await agent.getFootageSources().catch(() => []);
    if (!existing.length) {
      tmpWorkspace = fs.mkdtempSync(path.join(os.tmpdir(), 'thumb-ws-'));
      const vis = path.join(tmpWorkspace, 'assets', 'visuals'); fs.mkdirSync(vis, { recursive: true });
      const names = ['couple_argument_serious.mp4', 'person_thinking_alone.mp4', 'business_meeting_office.mp4'];
      names.forEach((n, i) => spawnSync(process.env.FFMPEG_PATH || 'ffmpeg', ['-y', '-loglevel', 'error', '-f', 'lavfi', '-i', `testsrc2=size=1280x720:rate=24:duration=3`, '-vf', `hue=h=${i * 90}`, '-pix_fmt', 'yuv420p', path.join(vis, n)]));
      process.env.OPENMONTAGE_WORKSPACE = tmpWorkspace;
      console.log('\nNo Cloudflare credentials and no footage: using synthetic test footage (ffmpeg testsrc2) for the LOCAL fallback test only.');
    } else console.log('\nNo Cloudflare credentials: testing local footage fallback with existing workspace footage.');
  } else console.log('\nCloudflare credentials found: running REAL FLUX generation.');

  try {
    const result = await agent.generateThumbnail({ title: '7 Signs You Are Being Gaslighted', script: 'Gaslighting makes you doubt your memory and your reality.' });
    console.log('mode:', result.generationMode, '| provider:', result.imageProvider);
    result.variants.forEach((v, i) => {
      const exists = fs.existsSync(v.path);
      ok(exists && v.dimensions.width === 1280 && v.dimensions.height === 720 && v.fileSize <= 2 * 1024 * 1024, `variant ${i + 1} ${v.label} "${v.hook}" -> ${v.path} (${(v.fileSize / 1024).toFixed(0)}KB, valid=${v.qualityChecks.valid})`);
      if (exists) fs.copyFileSync(v.path, path.join(outDir, `e2e-variant-${i + 1}.jpg`));
    });
    console.log('diversity:', JSON.stringify(result.qualityChecks.diversity));
    ok(result.qualityChecks.diversity.distinctFamilies === 3, 'three distinct families in end-to-end run');
  } catch (e) { ok(false, 'end-to-end generation: ' + e.message); }

  console.log(`\nOutput folder: ${outDir}\n${failures ? failures + ' FAILURE(S)' : 'ALL CHECKS PASSED'} (programmatic checks only; look at the images yourself)`);
  process.exit(failures ? 1 : 0);
})();
