# Production + Growth System (v11)

Node 20+ aur ffmpeg/ffprobe chahiye. Thumbnail pixel checks ke liye `sharp` (aapke project me pehle se hai).

## Layers (clean architecture)
    src/core    : pure logic, koi IO nahi (hook, interrupts, pacing, loudness, thumbnail rules, licence ledger, reuse risk)
    src/infra   : process supervisor, ffmpeg runner, checkpoint store, temp manager, jsonl store, thumbnail pixels
    src/app     : pipeline, chunked renderer, audio service, shot planner, report
    tests/      : 57+ tests (asli ffmpeg ke saath)
    scripts/    : run-tests.js, ci-hygiene.js, demo.js

## Chalana
    cd production-system
    npm test            # tests + warnings/leak check
    npm run hygiene     # static CI checks
    npm run demo        # nakli clips se poora pipeline

## Apne agent me jodna
    const { createProductionSystem } = require('./production-system/src');
    const sys = createProductionSystem({ root: 'C:\\yt\\state' });   // SHORT path rakho
    // har asset ek baar register karo (Pixabay clip, music, AI image):
    sys.ledger.register({ assetId, kind:'video', source:'pixabay', sourceUrl, author, licenseId:'pixabay-content-license' });
    const r = await sys.pipeline.run({ jobId, title, description, script, segments /*[{start,end,text}] TTS timings*/, words /*optional*/,
        narrationPath, clips:[{path, assetId}], musicPath, captionsAss, thumbnail:{ path, textBoxes:[{x,y,w,h,fontSize}], text }, outPath });
    // r.status: 'ready' | 'review' | 'blocked'; r.report.mustFix / consider; <out>.report.md bhi banta hai

## Features
1. Hook (pehle 5-15s): greeting, late start, punchy line, device, open loop, pace, dead air, title match. Score 0-100.
   Pattern interrupts: hook me har ~3-4s, baad me ~6-9s; zoom/flash ffmpeg se lagte hain, baqi (b-roll, sfx, text card) edit list me.
2. Dead air / filler: silencedetect se pauses chhote (0.28s rakhta hai), um/uh cut; aggressive mode optional. Captions ka time cuts ke baad khud theek hota hai.
   Loudness: two-pass loudnorm -14 LUFS, true peak <= -1.5; baad me measure karke verify.
3. Thumbnail: 360px aur 168px par contrast, safe zones (timestamp badge, margins, progress bar), font size, word count.
4. Licence ledger: har asset ka source/licence/hash. Block: unknown, non-commercial, ledger me nahi, attribution missing.
   Reuse risk: dusri videos se clip reuse, ek clip ka dominate karna, script similarity, same hook opening.
   Ye sab check render se PEHLE chalte hain; block ho to render shuru hi nahi hota.
5. Recovery: har stage ka checkpoint; render chhote chunks me hota hai, crash ke baad sirf adhoore chunks dobara bante hain.
   Hung ffmpeg (koi output nahi) stall detector se kill hota hai, poora process tree. Purane temp folders sirf marker wale delete hote hain.
6. CI hygiene: deprecated APIs, unused imports, console, focused tests, 'use strict'; test runner kisi bhi Node warning, leaked process ya temp folder par fail karta hai.

## Sound Design (v12)
Pipeline me `soundDesign: true` do (ya `{ acts, turns }`). Ye awaaz ke saath poora mix banata hai:
- **Acts:** script ~75 second ke acts me bantti hai; har act ka music mood (shuru curious, beech tense, akhir resolve; alfaaz saaf hon to unke mutabiq).
- **Turns:** "But...", "Turns out...", "The truth..." jaise jumlon par riser + hit. **Reveal** par pehle ~0.9s khamoshi (music gir jati hai), phir hit.
- **Interrupts:** zoom par halki whoosh (kam az kam 4s ke fasle par), text card par tick. SFX ka budget hai (~7/min), ghair zaroori pehle hat te hain.
- **Mix:** music awaaz ke neeche duck hoti hai (sidechain), halki brown-noise ambience, limiter, phir pipeline ka -14 LUFS normalise.
- **Cue sheet:** `r.data['sound-design'].sheet` me har bed/cue ka time aur level; `<out>.report.json` me bhi.

### Apni library lagana
    sounds/
      tense_drone.mp3      tense_drone.json
      riser_01.wav         riser_01.json
    { "kind": "music", "mood": "tense", "licenseId": "cc0", "source": "...", "sourceUrl": "...", "author": "...", "durationSec": 120 }
    { "kind": "sfx", "name": "riser", "licenseId": "cc0", "source": "..." }       // name: riser | hit | whoosh | tick
`createProductionSystem({ root, soundLibraryDir: 'C:\\yt\\sounds' })`.
- Jis file ka sidecar JSON na ho wo **ignore** hoti hai (licence maloom nahi).
- Library ka track pehle se asset ledger me chala jata hai; unknown/non-commercial licence par video block.
- Pichli 3 videos ke track dobara nahi chunta. Mood ka track na mile to neutral, phir koi bhi licensed track (report me `music_mood_mismatch`).
- Library na ho to khud-bani **placeholder** pads/SFX chalte hain. Ye sirf kaam chalau hain, asli music nahi: report me `placeholder_audio_in_use` aata hai.

## Hadood (sach)
- Hook score aur interrupts craft rules hain; retention ya algorithm ki guarantee nahi.
- Filler detection ke liye word-level timings chahiye (`words`). Bina unke sirf silence cut hota hai.
- Licence table convenience hai, legal advice nahi; har source ka term khud confirm karo.
- Windows par process-tree kill `taskkill` se hota hai; ye sandbox (Linux) me hi test hua hai.
- Sound design: awaaz ki jazbati quality aur music ka asli mizaj maine sun kar nahi parkha; sirf measure kiya (ducking >= 8 dB, silence drop >= 15 dB, loudness). Kaano se check aap karo.
- Test sirf nakli tone/testsrc clips par hue, asli TTS/Pixabay clips par nahi.
- `npm run hygiene` apna simple checker hai, ESLint nahi (eslint.config.js optional diya hai, chalaya nahi).
