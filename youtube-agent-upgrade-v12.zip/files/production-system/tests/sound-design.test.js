'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const S = require('../src/core/sound-design');
const { buildMixGraph } = require('../src/core/mix-graph');

const seg = (start, text, end = start + 3) => ({ start, end, text });

function longScript() {
  const out = [];
  for (let t = 0; t < 230; t += 5) out.push(seg(t, t === 100 ? 'But the truth is that nobody told you this.' : t === 150 ? 'Then everything changed.' : 'People learn to notice small patterns in behaviour.'));
  return out;
}

test('mood inference reads the wording', () => {
  assert.equal(S.inferMood('They manipulate and lie, it is a trap and a threat').mood, 'tense');
  assert.equal(S.inferMood('You can protect yourself and set boundaries to heal').mood, 'resolve');
  assert.equal(S.inferMood('The table is wooden').mood, 'neutral');
});

test('acts: short video is one act; long video splits near 75s on sentence starts; explicit acts win', () => {
  assert.equal(S.inferActs({ segments: [seg(0, 'a')], durationSec: 30 }).length, 1);
  const segs = longScript();
  const acts = S.inferActs({ segments: segs, durationSec: 234 });
  assert.ok(acts.length >= 3 && acts.length <= 4, 'acts ' + acts.length);
  assert.equal(acts[0].start, 0);
  assert.equal(acts[acts.length - 1].end, 234);
  for (const a of acts.slice(1)) assert.ok(segs.some(s => s.start === a.start), 'boundary on a sentence start');
  const explicit = S.inferActs({ segments: [{ ...seg(0, 'x'), act: 'a' }, { ...seg(10, 'y'), act: 'b' }, { ...seg(20, 'z'), act: 'b' }], durationSec: 60 });
  assert.deepEqual(explicit.map(a => a.start), [0, 10]);
});

test('mood arc: curious opening, resolve ending, given moods respected', () => {
  const acts = S.assignMoods([{ id: 'a1', start: 0, end: 50, text: '' }, { id: 'a2', start: 50, end: 100, text: '' }, { id: 'a3', start: 100, end: 150, text: '' }]);
  assert.deepEqual(acts.map(a => a.mood), ['curious', 'tense', 'resolve']);
  assert.equal(S.assignMoods([{ id: 'a', start: 0, end: 9, text: 'love', mood: 'sad' }])[0].mood, 'sad');
});

test('turns and reveals come from the script, with spacing', () => {
  const turns = S.findTurns({ segments: longScript(), durationSec: 234 });
  assert.deepEqual(turns.map(t => [t.t, t.kind]), [[100, 'reveal'], [150, 'turn']]);
  assert.deepEqual(S.findTurns({ segments: [seg(2, 'But no.')], durationSec: 100 }), [], 'too close to the start');
});

test('cue sheet: beds cover the video, riser+hit on turns, silence+hit on reveals, valid', () => {
  const sheet = S.planCues({ durationSec: 234, segments: longScript(), seed: 's' });
  assert.equal(sheet.beds[0].start, 0);
  assert.equal(sheet.beds[sheet.beds.length - 1].end, 234);
  assert.equal(sheet.beds[0].mood, 'curious');
  assert.equal(sheet.beds[sheet.beds.length - 1].mood, 'resolve');
  assert.ok(sheet.beds[0].gainDb < sheet.beds[1].gainDb || sheet.beds[0].mood !== sheet.beds[1].mood, 'hook bed sits lower');
  assert.deepEqual(sheet.drops, [{ start: 99.1, end: 100 }]);
  assert.ok(sheet.sfx.some(s => s.kind === 'hit' && s.t === 100 && s.why === 'reveal'));
  assert.ok(sheet.sfx.some(s => s.kind === 'riser' && s.endsAt === 150));
  assert.equal(S.validateCueSheet(sheet).ok, true);
});

test('cue sheet is deterministic and different seeds change small details only', () => {
  const args = { durationSec: 120, segments: longScript(), interrupts: [{ t: 5, type: 'cut-zoom' }, { t: 20, type: 'text-card' }] };
  assert.deepEqual(S.planCues({ ...args, seed: 'a' }), S.planCues({ ...args, seed: 'a' }));
});

test('interrupts map to whoosh/tick, whooshes are spaced, cues avoid silence drops, budget is enforced', () => {
  const interrupts = [];
  for (let t = 3; t < 118; t += 1.2) interrupts.push({ t, type: t % 2 < 1 ? 'cut-zoom' : 'text-card' });
  const sheet = S.planCues({ durationSec: 120, segments: [], interrupts, turns: [{ t: 60, kind: 'reveal' }], seed: 'b' });
  const whooshes = sheet.sfx.filter(s => s.kind === 'whoosh');
  for (let i = 1; i < whooshes.length; i++) assert.ok(whooshes[i].t - whooshes[i - 1].t >= 3.9);
  assert.ok(sheet.sfx.length <= 14);
  assert.ok(sheet.sfx.some(s => s.kind === 'hit'), 'important cues survive trimming');
  assert.ok(sheet.sfx.filter(s => s.kind !== 'hit').every(s => s.t < 58.4 || s.t > 61.1), 'nothing inside the silence');
  assert.equal(S.validateCueSheet(sheet).ok, true);
});

test('validator catches loud music, gaps, long silences and sfx floods', () => {
  const sheet = S.planCues({ durationSec: 100, segments: [], seed: 'v' });
  const bad = JSON.parse(JSON.stringify(sheet));
  bad.beds[0].gainDb = -6; bad.beds[0].end = 40; bad.drops = [{ start: 10, end: 14 }];
  bad.sfx = Array.from({ length: 40 }, (_, i) => ({ kind: 'tick', t: i + 1, gainDb: -24 }));
  const r = S.validateCueSheet(bad);
  assert.equal(r.ok, false);
  for (const want of ['music_too_loud_under_voice', 'music_ends_early', 'silence_drop_too_long', 'too_many_sfx']) assert.ok(r.issues.includes(want), want);
  assert.throws(() => S.planCues({}), /durationSec/);
});

test('mix graph: ducking, drops, one delay per cue, ambience, limiter', () => {
  const sheet = S.planCues({ durationSec: 120, segments: [], interrupts: [{ t: 5, type: 'cut-zoom' }, { t: 20, type: 'text-card' }, { t: 30, type: 'text-card' }], turns: [{ t: 60, kind: 'reveal' }, { t: 90, kind: 'turn' }], seed: 'g' });
  const sfxKinds = [...new Set(sheet.sfx.map(s => s.kind))];
  const sfx = {}; let idx = sheet.beds.length + 1;
  for (const k of sfxKinds) sfx[k] = { index: idx++, count: sheet.sfx.filter(s => s.kind === k).length };
  const g = buildMixGraph(sheet, { beds: sheet.beds.map((_, i) => ({ index: i + 1 })), sfx });
  assert.match(g.filter, /sidechaincompress/);
  assert.equal((g.filter.match(/volume=eval=frame/g) || []).length, sheet.drops.length);
  assert.equal((g.filter.match(/adelay=\d+:all=1\[s_/g) || []).length, sheet.sfx.length);
  assert.match(g.filter, /anoisesrc/);
  assert.match(g.filter, /alimiter/);
  assert.equal(g.outLabel, 'mix');
});
