'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { FfmpegRunner } = require('../src/infra/ffmpeg-runner');
const { SfxSynth } = require('../src/infra/sfx-synth');
const { SoundLibrary, SoundHistory } = require('../src/infra/sound-library');
const { SoundDesigner } = require('../src/app/sound-designer');
const { LicenseLedger } = require('../src/core/license-ledger');
const { MemoryStore } = require('../src/infra/jsonl-store');
const h = require('./helpers');

/** Mean level (dB) of a band of the file between two times. */
function bandLevel(file, from, to, filter) {
  const r = spawnSync(process.env.FFMPEG_PATH || 'ffmpeg', ['-hide_banner', '-nostats', '-ss', String(from), '-t', String(to - from), '-i', file, '-af', filter + ',volumedetect', '-f', 'null', '-'], { encoding: 'utf8' });
  return parseFloat(/mean_volume:\s*(-?[\d.]+)/.exec(r.stderr)[1]);
}

/** 4 s of voice tone then 4 s of silence. */
function voiceThenSilence(file) {
  h.ff(['-f', 'lavfi', '-t', '4', '-i', 'sine=frequency=220:sample_rate=48000', '-f', 'lavfi', '-t', '4', '-i', 'anullsrc=r=48000:cl=mono', '-filter_complex', '[0:a][1:a]concat=n=2:v=0:a=1[a]', '-map', '[a]', '-c:a', 'pcm_s16le', file]);
}

function libraryWithToneMusic(dir) {
  const lib = path.join(dir, 'lib'); fs.mkdirSync(lib);
  h.makeTone(path.join(lib, 'bed.wav'), { seconds: 20, freq: 1500, volume: 4 });
  fs.writeFileSync(path.join(lib, 'bed.json'), JSON.stringify({ kind: 'music', mood: 'curious', licenseId: 'cc0', source: 'test', sourceUrl: 'https://example.invalid/bed', author: 'T' }));
  return new SoundLibrary(lib);
}

test('synthesised effects and pads have the expected length', async () => {
  const dir = h.tmp();
  try {
    const runner = new FfmpegRunner(), synth = new SfxSynth(runner);
    for (const kind of ['hit', 'riser', 'whoosh', 'tick']) {
      const r = await synth.effect(kind, path.join(dir, kind + '.wav'));
      assert.ok(Math.abs((await runner.probe(r.path)).duration - r.seconds) < 0.1, kind);
    }
    const pad = await synth.pad('tense', 7, path.join(dir, 'pad.wav'));
    assert.ok(Math.abs((await runner.probe(pad.path)).duration - 7) < 0.1);
    await assert.rejects(synth.effect('laser', path.join(dir, 'x.wav')), /unknown effect/);
  } finally { h.rm(dir); }
});

test('designer: placeholder mix has the right length and is flagged as placeholder', async () => {
  const dir = h.tmp();
  try {
    const nar = h.makeNarration(path.join(dir, 'n.wav'));
    const runner = new FfmpegRunner();
    const r = await new SoundDesigner({ runner }).design({ jobId: 'j', narrationPath: nar.file, segments: [{ start: 0.2, end: 2, text: 'Your brain is lying to you.' }], interrupts: [{ t: 3, type: 'cut-zoom' }, { t: 9, type: 'text-card' }], workDir: path.join(dir, 'w'), outPath: path.join(dir, 'mix.wav') });
    assert.ok(Math.abs((await runner.probe(r.outPath)).duration - nar.duration) < 0.15);
    assert.ok(r.placeholders.length >= 1);
    assert.equal(r.summary.placeholderAssets, r.placeholders.length);
    assert.equal(fs.readdirSync(dir).some(n => n.includes('.part')), false);
  } finally { h.rm(dir); }
});

test('music ducks under the voice and comes back in the pauses (measured)', async () => {
  const dir = h.tmp();
  try {
    const nar = path.join(dir, 'vs.wav'); voiceThenSilence(nar);
    const library = libraryWithToneMusic(dir);
    const r = await new SoundDesigner({ runner: new FfmpegRunner(), library }).design({ jobId: 'duck', narrationPath: nar, segments: [], workDir: path.join(dir, 'w'), outPath: path.join(dir, 'mix.wav') });
    assert.deepEqual(r.sheet.beds.map(b => b.track.assetId), ['lib-bed']);
    assert.equal(r.sheet.beds[0].track.moodMatch, false, 'falls back to the only licensed track and says so');
    assert.equal(r.summary.moodMismatches, 1);
    const hi = 'highpass=f=1000';
    const speaking = bandLevel(r.outPath, 1.5, 3.5, hi);
    const pause = bandLevel(r.outPath, 4.8, 4.98, hi);
    assert.ok(pause - speaking >= 8, 'music should be at least 8 dB lower while speaking: speaking ' + speaking + ' pause ' + pause);
  } finally { h.rm(dir); }
});

test('silence before a reveal drops the music, then the hit lands', async () => {
  const dir = h.tmp();
  try {
    const nar = path.join(dir, 'quiet.wav'); h.ff(['-f', 'lavfi', '-t', '8', '-i', 'anullsrc=r=48000:cl=mono', '-c:a', 'pcm_s16le', nar]);
    const library = libraryWithToneMusic(dir);
    const r = await new SoundDesigner({ runner: new FfmpegRunner(), library }).design({ jobId: 'drop', narrationPath: nar, segments: [], turns: [{ t: 5, kind: 'reveal' }], workDir: path.join(dir, 'w'), outPath: path.join(dir, 'mix.wav') });
    assert.deepEqual(r.sheet.drops, [{ start: 4.1, end: 5 }]);
    const band = 'bandpass=f=1500:width_type=h:w=300';
    const before = bandLevel(r.outPath, 2.5, 3.5, band);
    const during = bandLevel(r.outPath, 4.35, 4.85, band);
    assert.ok(before - during >= 15, 'drop depth ' + (before - during) + ' dB');
    const hit = bandLevel(r.outPath, 5.0, 5.4, 'lowpass=f=200');
    const beforeHit = bandLevel(r.outPath, 3.0, 3.4, 'lowpass=f=200');
    assert.ok(hit - beforeHit > 10, 'low-frequency impact is audible: ' + hit + ' vs ' + beforeHit);
  } finally { h.rm(dir); }
});

test('library: unlabelled files are ignored, rotation avoids recent tracks, ledger records licences', async () => {
  const dir = h.tmp();
  try {
    const lib = path.join(dir, 'lib'); fs.mkdirSync(lib);
    for (const n of ['a', 'b']) { h.makeTone(path.join(lib, n + '.wav'), { seconds: 3 }); fs.writeFileSync(path.join(lib, n + '.json'), JSON.stringify({ kind: 'music', mood: 'tense', licenseId: n === 'a' ? 'cc0' : 'cc-by-nc-4.0', source: 's', sourceUrl: 'u', author: 'X' })); }
    h.makeTone(path.join(lib, 'orphan.wav'), { seconds: 3 });
    const library = new SoundLibrary(lib);
    assert.equal(library.items.length, 2);
    assert.equal(library.skipped.length, 1);
    assert.match(library.skipped[0].why, /licence unknown/);
    assert.equal(library.select({ kind: 'music', mood: 'tense', seed: 'q', avoid: ['lib-a'] }).assetId, 'lib-b');
    assert.equal(library.select({ kind: 'music', mood: 'sad' }), null);

    const history = new SoundHistory(path.join(dir, 'hist.json'));
    history.record('v1', ['lib-a']); history.record('v2', ['lib-b']);
    assert.deepEqual(history.recentAssetIds(3).sort(), ['lib-a', 'lib-b']);

    const ledger = new LicenseLedger(new MemoryStore());
    const nar = path.join(dir, 'n.wav'); h.makeTone(nar, { seconds: 6, freq: 200 });
    const r = await new SoundDesigner({ runner: new FfmpegRunner(), library, ledger }).design({ jobId: 'led', narrationPath: nar, segments: [], workDir: path.join(dir, 'w'), outPath: path.join(dir, 'm.wav') });
    const assets = ledger.records().assets;
    const used = r.usage.map(u => u.assetId).filter(id => id.startsWith('lib-'));
    assert.equal(used.length, 1);
    assert.equal(assets.get(used[0]).kind, 'audio');
    assert.ok(assets.get(used[0]).sha256.length === 64);
    assert.ok(assets.has('synth-sfx-tick') || r.usage.length >= 1);
  } finally { h.rm(dir); }
});
