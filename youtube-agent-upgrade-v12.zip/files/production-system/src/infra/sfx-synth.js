'use strict';
/**
 * Procedural sound effects and placeholder music pads made with ffmpeg only.
 * They let the system run with no downloaded audio. They are simple synthesised sounds, NOT a replacement for
 * licensed music: every pad is reported as "placeholder" so it gets swapped for a real track.
 */
const SR = 48000;

const CHORDS = {
  tense: [55, 82.4, 110, 116.5],
  curious: [110, 165, 220, 330],
  sad: [110, 130.8, 164.8, 220],
  resolve: [130.8, 164.8, 196, 261.6],
  neutral: [98, 147, 196]
};

const lavfi = {
  hit: () => ({ src: "aevalsrc='(sin(2*PI*52*t)+0.5*sin(2*PI*104*t))*exp(-4.5*t)*0.8':d=1.4:s=" + SR, seconds: 1.4 }),
  riser: () => ({ src: "aevalsrc='0.5*sin(2*PI*(120*t+90*t*t))*pow(t/2.4,2)':d=2.4:s=" + SR, seconds: 2.4 }),
  whoosh: () => ({ src: 'anoisesrc=d=0.7:c=pink:r=' + SR + ':a=0.5,highpass=f=400,lowpass=f=5000,afade=t=in:st=0:d=0.3,afade=t=out:st=0.3:d=0.4', seconds: 0.7 }),
  tick: () => ({ src: "aevalsrc='sin(2*PI*1600*t)*exp(-60*t)':d=0.12:s=" + SR, seconds: 0.12 })
};

function padSource(mood, seconds) {
  const freqs = CHORDS[mood] || CHORDS.neutral;
  const sum = freqs.map(f => 'sin(2*PI*' + f + '*t)').join('+');
  const amp = (0.5 / freqs.length).toFixed(3);
  const d = Math.max(1, seconds).toFixed(2);
  const fade = Math.min(0.5, seconds / 4).toFixed(2);
  return "aevalsrc='(" + sum + ")*" + amp + "*(0.75+0.25*sin(2*PI*0.1*t))':d=" + d + ':s=' + SR + ',lowpass=f=1200,afade=t=in:st=0:d=' + fade + ',afade=t=out:st=' + (seconds - Number(fade)).toFixed(2) + ':d=' + fade;
}

class SfxSynth {
  constructor(runner) { this.runner = runner; }

  async effect(kind, outFile) {
    if (!lavfi[kind]) throw new Error('unknown effect kind: ' + kind);
    const { src, seconds } = lavfi[kind]();
    await this.runner.run(['-f', 'lavfi', '-i', src, '-ac', '2', '-c:a', 'pcm_s16le', outFile], { label: 'synth ' + kind });
    return { path: outFile, seconds };
  }

  async pad(mood, seconds, outFile) {
    await this.runner.run(['-f', 'lavfi', '-i', padSource(mood, seconds), '-ac', '2', '-c:a', 'pcm_s16le', outFile], { label: 'synth pad ' + mood });
    return { path: outFile, seconds };
  }
}

module.exports = { SfxSynth, CHORDS };
