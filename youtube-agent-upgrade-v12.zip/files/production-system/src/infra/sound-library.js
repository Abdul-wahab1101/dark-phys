'use strict';
/**
 * Folder-based sound library. Each audio file may have a sidecar JSON with the same base name:
 *   { "kind": "music"|"sfx", "mood": "tense", "name": "riser", "licenseId": "cc0", "source": "...", "sourceUrl": "...", "author": "...", "durationSec": 120 }
 * Files without a sidecar are ignored on purpose: an unlabelled file has no known licence.
 */
const fs = require('fs');
const path = require('path');
const { mulberry32, seedFrom } = require('../core/rng');
const { writeFileAtomic } = require('./file-utils');

const AUDIO = /\.(mp3|wav|ogg|m4a|flac)$/i;

class SoundLibrary {
  constructor(dir) {
    this.dir = dir;
    this.items = [];
    this.skipped = [];
    this.scan();
  }

  scan() {
    this.items = []; this.skipped = [];
    if (!this.dir || !fs.existsSync(this.dir)) return;
    for (const name of fs.readdirSync(this.dir)) {
      if (!AUDIO.test(name)) continue;
      const file = path.join(this.dir, name);
      const side = file.replace(AUDIO, '.json');
      if (!fs.existsSync(side)) { this.skipped.push({ file, why: 'no sidecar json (licence unknown)' }); continue; }
      try {
        const meta = JSON.parse(fs.readFileSync(side, 'utf8'));
        this.items.push({ assetId: meta.assetId || 'lib-' + path.basename(name, path.extname(name)), path: file, kind: meta.kind || 'music', mood: meta.mood || 'neutral', name: meta.name || null, licenseId: meta.licenseId || 'unknown', source: meta.source || 'library', sourceUrl: meta.sourceUrl || null, author: meta.author || null, durationSec: meta.durationSec || null });
      } catch (e) { this.skipped.push({ file, why: 'bad sidecar: ' + e.message }); }
    }
  }

  /** Picks an item, preferring ones not used recently. Deterministic for a seed. */
  select({ kind, mood = null, name = null, seed = 'x', avoid = [], minSeconds = 0 }) {
    let pool = this.items.filter(i => i.kind === kind && (!mood || i.mood === mood) && (!name || i.name === name) && (!minSeconds || !i.durationSec || i.durationSec >= minSeconds));
    if (!pool.length) return null;
    const fresh = pool.filter(i => !avoid.includes(i.assetId));
    if (fresh.length) pool = fresh;
    return pool[Math.floor(mulberry32(seedFrom(seed))() * pool.length) % pool.length];
  }
}

/** Remembers which assets the last videos used so music does not repeat video after video. */
class SoundHistory {
  constructor(file, { keep = 8 } = {}) { this.file = file; this.keep = keep; }
  read() { try { return JSON.parse(fs.readFileSync(this.file, 'utf8')).recent || []; } catch (_) { return []; } }
  recentAssetIds(lastN = 3) { return this.read().slice(-lastN).flatMap(r => r.assetIds); }
  record(videoId, assetIds) {
    const recent = this.read().filter(r => r.videoId !== videoId);
    recent.push({ videoId, assetIds: [...new Set(assetIds)] });
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    writeFileAtomic(this.file, JSON.stringify({ recent: recent.slice(-this.keep) }));
  }
}

module.exports = { SoundLibrary, SoundHistory };
