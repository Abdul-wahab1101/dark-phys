'use strict';
/** Turns narration + script timings into a finished, mixed audio track and a cue sheet. */
const fs = require('fs');
const path = require('path');
const { inferActs, planCues, validateCueSheet } = require('../core/sound-design');
const { buildMixGraph } = require('../core/mix-graph');
const { SfxSynth } = require('../infra/sfx-synth');
const { hashFile } = require('../infra/file-utils');

const SFX_KINDS = ['riser', 'hit', 'whoosh', 'tick'];

class SoundDesigner {
  constructor({ runner, library = null, history = null, ledger = null }) {
    Object.assign(this, { runner, library, history, ledger });
    this.synth = new SfxSynth(runner);
  }

  /**
   * @param {{jobId:string, narrationPath:string, segments?:Array, acts?:Array, interrupts?:Array, turns?:Array, seed?:string,
   *          workDir:string, outPath:string}} o
   */
  async design(o) {
    const info = await this.runner.probe(o.narrationPath);
    const durationSec = info.duration;
    const acts = o.acts || inferActs({ segments: o.segments || [], durationSec });
    const sheet = planCues({ durationSec, segments: o.segments || [], acts, interrupts: o.interrupts || [], turns: o.turns, seed: o.seed || o.jobId });
    const validation = validateCueSheet(sheet);
    if (!validation.ok) throw new Error('cue sheet invalid: ' + validation.issues.join(', '));

    fs.mkdirSync(o.workDir, { recursive: true });
    const avoid = this.history ? this.history.recentAssetIds(3) : [];
    const used = new Map();   // assetId -> { assetId, path, kind, meta, placeholder, secondsUsed, uses }
    const note = (a, sec) => {
      const cur = used.get(a.assetId) || { ...a, secondsUsed: 0, uses: 0 };
      cur.secondsUsed = Number((cur.secondsUsed + sec).toFixed(2)); cur.uses++;
      used.set(a.assetId, cur);
    };

    const inputFiles = [];            // extra ffmpeg inputs after the narration
    const addInput = (file, loop) => { inputFiles.push({ file, loop }); return inputFiles.length; };

    const bedInputs = [];
    for (let i = 0; i < sheet.beds.length; i++) {
      const b = sheet.beds[i], len = b.end - b.start;
      let lib = null;
      if (this.library) {
        // exact mood first, then a neutral track, then any licensed track (a real track beats a synthetic placeholder)
        for (const mood of [b.mood, 'neutral', null]) {
          lib = this.library.select({ kind: 'music', mood, seed: o.jobId + b.actId, avoid });
          if (lib) { b.moodMatch = mood === b.mood; break; }
        }
      }
      if (lib) {
        const sec = lib.durationSec || (await this.runner.probe(lib.path)).duration;
        const loop = sec < len;
        b.track = { assetId: lib.assetId, loops: loop, moodMatch: b.moodMatch };
        bedInputs.push({ index: addInput(lib.path, loop) });
        note({ assetId: lib.assetId, path: lib.path, kind: 'audio', meta: lib, placeholder: false }, len);
      } else {
        const file = path.join(o.workDir, 'pad_' + b.actId + '_' + b.mood + '.wav');
        await this.synth.pad(b.mood, len, file);
        const id = 'synth-pad-' + b.mood;
        b.track = { assetId: id, placeholder: true };
        bedInputs.push({ index: addInput(file, false) });
        note({ assetId: id, path: file, kind: 'audio', meta: { source: 'synthetic', licenseId: 'own' }, placeholder: true }, len);
      }
    }

    const sfxInputs = {};
    for (const kind of SFX_KINDS) {
      const cues = sheet.sfx.filter(s => s.kind === kind);
      if (!cues.length) continue;
      const lib = this.library ? this.library.select({ kind: 'sfx', name: kind, seed: o.jobId + kind, avoid }) : null;
      let file, id, placeholder = false, meta;
      if (lib) { file = lib.path; id = lib.assetId; meta = lib; } else {
        file = path.join(o.workDir, 'sfx_' + kind + '.wav');
        await this.synth.effect(kind, file);
        id = 'synth-sfx-' + kind; placeholder = true; meta = { source: 'synthetic', licenseId: 'own' };
      }
      sfxInputs[kind] = { index: addInput(file, false), count: cues.length };
      note({ assetId: id, path: file, kind: 'audio', meta, placeholder }, cues.length * 1);
    }

    const graph = buildMixGraph(sheet, { beds: bedInputs, sfx: sfxInputs });
    const args = ['-i', o.narrationPath];
    for (const inp of inputFiles) { if (inp.loop) args.push('-stream_loop', '-1'); args.push('-i', inp.file); }
    const part = o.outPath + '.part.wav';
    args.push('-filter_complex', graph.filter, '-map', '[' + graph.outLabel + ']', '-t', durationSec.toFixed(3), '-ar', '48000', '-c:a', 'pcm_s16le', part);
    await this.runner.run(args, { cwd: o.workDir, label: 'sound-mix' });
    fs.renameSync(part, o.outPath);

    const assets = [...used.values()];
    if (this.ledger) await this.registerAssets(assets);
    if (this.history) this.history.record(o.jobId, assets.filter(a => !a.placeholder).map(a => a.assetId));

    const placeholders = assets.filter(a => a.placeholder).map(a => a.assetId);
    return {
      outPath: o.outPath, durationSec, sheet, validation,
      usage: assets.map(a => ({ assetId: a.assetId, secondsUsed: a.secondsUsed, uses: a.uses })),
      placeholders,
      summary: { moodMismatches: sheet.beds.filter(b => b.moodMatch === false).length, beds: sheet.beds.length, moods: sheet.beds.map(b => b.mood), sfx: sheet.sfx.length, drops: sheet.drops.length, placeholderAssets: placeholders.length }
    };
  }

  async registerAssets(assets) {
    const known = this.ledger.records().assets;
    for (const a of assets) {
      if (known.has(a.assetId)) continue;
      const m = a.meta || {};
      this.ledger.register({
        assetId: a.assetId, kind: 'audio', source: m.source || 'library', sourceUrl: m.sourceUrl || null, author: m.author || null,
        licenseId: m.licenseId || 'unknown', sha256: a.placeholder ? null : await hashFile(a.path)
      });
    }
  }
}

module.exports = { SoundDesigner, SFX_KINDS };
