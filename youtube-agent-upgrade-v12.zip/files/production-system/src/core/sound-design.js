'use strict';
/**
 * Sound design planning (pure logic): story acts, music mood per act, story turns, riser/hit/whoosh cues,
 * deliberate silence before reveals, and a validator. Output is a cue sheet that the mixer turns into audio.
 */
const { mulberry32, seedFrom } = require('./rng');

const MOODS = ['tense', 'curious', 'sad', 'resolve', 'neutral'];

const LEXICON = {
  tense: ['fear', 'danger', 'trap', 'control', 'manipulat', 'lie', 'lies', 'secret', 'threat', 'pressure', 'hidden', 'warning', 'gaslight', 'dark', 'silent', 'victim', 'weapon', 'exploit', 'deceiv', 'coerc'],
  curious: ['why', 'how', 'discover', 'experiment', 'study', 'research', 'mystery', 'question', 'strange', 'surpris', 'turns', 'notice', 'brain', 'psycholog'],
  sad: ['lonely', 'loss', 'pain', 'hurt', 'cry', 'alone', 'broken', 'grief', 'regret', 'abandon'],
  resolve: ['learn', 'protect', 'solution', 'free', 'recover', 'boundar', 'heal', 'strong', 'choose', 'clarity', 'awareness', 'recogni']
};

/** Gain of each music bed in dB relative to full scale of the bed file; the voice sits well above these. */
const LEVELS = {
  bed: { tense: -22, curious: -24, sad: -24, resolve: -23, neutral: -25 },
  hookExtraDb: -2,
  riserDb: -20, hitRevealDb: -14, hitTurnDb: -18, whooshDb: -26, tickDb: -24,
  ambienceDb: -40,
  crossfadeSec: 1.5, introFadeSec: 1.0, outroFadeSec: 3.0, dropFloor: 0.04
};

const TURN_RE = /^\W*(but|until|then|except|however|and that'?s when|the truth|turns out|the real reason|what nobody|what no one|here'?s the)\b/i;
const REVEAL_RE = /\b(the truth|turns out|the real reason|nobody|no one|secret|here'?s what)\b/i;

function inferMood(text) {
  const words = String(text || '').toLowerCase().match(/[a-z']+/g) || [];
  const score = {};
  for (const m of Object.keys(LEXICON)) score[m] = words.filter(w => LEXICON[m].some(k => w.startsWith(k))).length;
  const best = Object.keys(score).sort((a, b) => score[b] - score[a])[0];
  return score[best] > 0 ? { mood: best, score: score[best] } : { mood: 'neutral', score: 0 };
}

function arcMood(i, n) {
  if (n === 1) return 'tense';
  if (i === 0) return 'curious';
  if (i === n - 1) return 'resolve';
  return 'tense';
}

/** Split the timeline into acts: honours explicit `act` ids on segments, else cuts near every ~75s at sentence starts. */
function inferActs({ segments = [], durationSec, targetActSec = 75, shortBelowSec = 45 }) {
  if (!(durationSec > 0)) throw new Error('durationSec is required');
  const segs = [...segments].sort((a, b) => a.start - b.start);
  let bounds;
  if (segs.some(s => s.act !== undefined)) {
    bounds = [];
    let last;
    for (const s of segs) if (s.act !== last) { bounds.push(bounds.length ? s.start : 0); last = s.act; }
  } else if (durationSec < shortBelowSec) {
    bounds = [0];
  } else {
    const n = Math.max(1, Math.round(durationSec / targetActSec));
    bounds = [0];
    for (let k = 1; k < n; k++) {
      const ideal = (durationSec / n) * k;
      const near = segs.map(s => s.start).filter(t => Math.abs(t - ideal) <= targetActSec * 0.35).sort((a, b) => Math.abs(a - ideal) - Math.abs(b - ideal))[0];
      bounds.push(near !== undefined ? near : ideal);
    }
  }
  bounds = [...new Set(bounds.map(b => Number(b.toFixed(2))))].sort((a, b) => a - b);
  return bounds.map((start, i) => {
    const end = i + 1 < bounds.length ? bounds[i + 1] : durationSec;
    const text = segs.filter(s => s.start >= start && s.start < end).map(s => s.text).join(' ');
    const explicit = segs.find(s => s.start >= start && s.start < end && s.mood);
    return { id: 'act' + (i + 1), start, end: Number(end.toFixed(2)), text, mood: explicit ? explicit.mood : undefined };
  });
}

function assignMoods(acts) {
  return acts.map((a, i) => {
    if (a.mood && MOODS.includes(a.mood)) return { ...a, moodSource: 'given' };
    const lex = inferMood(a.text);
    const arc = arcMood(i, acts.length);
    const first = i === 0, last = i === acts.length - 1 && acts.length > 1;
    // the opening stays curious and the ending resolves unless the wording is clearly darker
    const dark = lex.mood === 'tense' || lex.mood === 'sad';
    const useLex = last ? dark && lex.score >= 3 : first && acts.length > 1 ? lex.mood === 'tense' && lex.score >= 2 : lex.score >= 2;
    return { ...a, mood: useLex ? lex.mood : arc, moodSource: useLex ? 'wording' : 'arc' };
  });
}

/** Story turns ("but...", "turns out...") picked from the script; reveals get a silence + hit. */
function findTurns({ segments = [], durationSec, minGapSec = 12, maxPerMinute = 2, edgeSec = 6 }) {
  const turns = [];
  for (const s of [...segments].sort((a, b) => a.start - b.start)) {
    if (s.start < edgeSec || s.start > durationSec - edgeSec) continue;
    if (!TURN_RE.test(s.text || '')) continue;
    const prev = turns[turns.length - 1];
    if (prev && s.start - prev.t < minGapSec) continue;
    const inLastMinute = turns.filter(t => t.t > s.start - 60).length;
    if (inLastMinute >= maxPerMinute) continue;
    turns.push({ t: Number(s.start.toFixed(2)), kind: REVEAL_RE.test(s.text) ? 'reveal' : 'turn' });
  }
  return turns;
}

const SFX_FOR_INTERRUPT = { 'text-card': 'tick', 'cut-zoom': 'whoosh', 'speed-ramp': 'whoosh', 'sfx-hit': 'tick', 'caption-emphasis': 'tick' };
const PRIORITY = { hit: 4, riser: 4, whoosh: 2, tick: 1 };

function planCues({ durationSec, segments = [], acts, interrupts = [], turns, seed = 'sound', levels = LEVELS, hookWindowSec = 15, maxSfxPerMinute = 7 } = {}) {
  if (!(durationSec > 0)) throw new Error('durationSec is required');
  const rng = mulberry32(seedFrom(seed));
  const actList = assignMoods(acts && acts.length ? acts : inferActs({ segments, durationSec }));
  const xf = levels.crossfadeSec;

  const beds = actList.map((a, i) => {
    const first = i === 0, last = i === actList.length - 1;
    const start = first ? 0 : a.start - xf / 2;
    const end = last ? durationSec : actList[i + 1].start + xf / 2;
    return {
      actId: a.id, mood: a.mood, moodSource: a.moodSource, start: Number(Math.max(0, start).toFixed(2)), end: Number(Math.min(durationSec, end).toFixed(2)),
      gainDb: levels.bed[a.mood] + (first ? levels.hookExtraDb : 0),
      fadeInSec: first ? levels.introFadeSec : xf, fadeOutSec: last ? levels.outroFadeSec : xf
    };
  });

  const storyTurns = turns || findTurns({ segments, durationSec });
  const sfx = [];
  const drops = [];
  for (const t of storyTurns) {
    if (t.kind === 'reveal') {
      drops.push({ start: Number(Math.max(0, t.t - 0.9).toFixed(2)), end: t.t });
      sfx.push({ kind: 'hit', t: t.t, gainDb: levels.hitRevealDb, why: 'reveal' });
    } else {
      sfx.push({ kind: 'riser', t: Number(Math.max(0, t.t - 2.4).toFixed(2)), gainDb: levels.riserDb, why: 'turn', endsAt: t.t });
      sfx.push({ kind: 'hit', t: t.t, gainDb: levels.hitTurnDb, why: 'turn' });
    }
  }

  let lastWhoosh = -99;
  for (const it of [...interrupts].sort((a, b) => a.t - b.t)) {
    const kind = SFX_FOR_INTERRUPT[it.type];
    if (!kind || it.t < 0.5 || it.t > durationSec - 2) continue;
    if (kind === 'whoosh' && it.t - lastWhoosh < 4) continue;
    if (drops.some(d => it.t > d.start - 0.5 && it.t < d.end + 0.5)) continue;
    if (sfx.some(s => Math.abs(s.t - it.t) < 1.0 && PRIORITY[s.kind] >= 4)) continue;
    if (kind === 'whoosh') lastWhoosh = it.t;
    sfx.push({ kind, t: it.t, gainDb: kind === 'whoosh' ? levels.whooshDb : levels.tickDb, why: it.type });
  }

  // budget: drop the least important cues first when too dense
  const budget = Math.max(3, Math.ceil((durationSec / 60) * maxSfxPerMinute));
  let kept = [...sfx];
  while (kept.length > budget) {
    const worst = kept.reduce((w, c) => (PRIORITY[c.kind] < PRIORITY[w.kind] || (PRIORITY[c.kind] === PRIORITY[w.kind] && c.t > w.t)) ? c : w);
    if (PRIORITY[worst.kind] >= 4) break;
    kept = kept.filter(c => c !== worst);
  }
  kept.sort((a, b) => a.t - b.t);
  const jitter = () => Number(((rng() - 0.5) * 0.04).toFixed(3));
  kept.forEach(c => { if (c.kind === 'tick' || c.kind === 'whoosh') c.t = Number(Math.max(0, c.t + jitter()).toFixed(3)); });

  return { durationSec, hookWindowSec, acts: actList.map(a => ({ id: a.id, start: a.start, end: a.end, mood: a.mood, moodSource: a.moodSource })), beds, sfx: kept, drops, ambience: { gainDb: levels.ambienceDb }, levels };
}

function validateCueSheet(sheet, { maxSfxPerMinute = 8, maxDropSec = 2.0, maxBedDb = -18 } = {}) {
  const issues = [];
  const { beds, sfx, drops, durationSec } = sheet;
  if (!beds.length) issues.push('no_music_beds');
  else {
    if (beds[0].start > 0.01) issues.push('music_starts_late');
    if (beds[beds.length - 1].end < durationSec - 0.01) issues.push('music_ends_early');
    for (let i = 1; i < beds.length; i++) {
      if (beds[i].start > beds[i - 1].end + 0.01) issues.push('gap_between_beds_' + i);
      if (beds[i - 1].end - beds[i].start > sheet.levels.crossfadeSec * 2 + 0.1) issues.push('beds_overlap_too_long_' + i);
    }
    if (beds.some(b => b.gainDb > maxBedDb)) issues.push('music_too_loud_under_voice');
  }
  if (sfx.length > Math.max(3, Math.ceil((durationSec / 60) * maxSfxPerMinute))) issues.push('too_many_sfx');
  if (drops.some(d => d.end - d.start > maxDropSec)) issues.push('silence_drop_too_long');
  if (drops.length > Math.max(1, Math.ceil(durationSec / 100))) issues.push('too_many_silence_drops');
  for (const s of sfx) if (s.t < 0 || s.t > durationSec) issues.push('sfx_outside_timeline');
  return { ok: issues.length === 0, issues: [...new Set(issues)] };
}

module.exports = { MOODS, LEVELS, inferMood, inferActs, assignMoods, findTurns, planCues, validateCueSheet };
