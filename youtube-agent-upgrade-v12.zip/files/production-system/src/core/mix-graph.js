'use strict';
/**
 * Builds the ffmpeg filter_complex for a cue sheet (pure string building).
 * Input 0 is the narration. Music beds and SFX are extra inputs described by `inputs`.
 *   inputs.beds: [{ index }]  one per sheet.beds entry, in the same order
 *   inputs.sfx:  { riser: {index, count}, hit: {...} }  one input per kind, split into `count` copies
 */
const SR = 48000;
const n = v => Number(v).toFixed(3);

function buildMixGraph(sheet, inputs, { duckThreshold = 0.02, duckRatio = 8, ambience = true } = {}) {
  const parts = [];
  parts.push('[0:a]aresample=' + SR + ',asplit=2[vo][sc]');

  const bedLabels = sheet.beds.map((b, i) => {
    const len = b.end - b.start;
    const label = 'mb' + i;
    parts.push('[' + inputs.beds[i].index + ':a]aresample=' + SR + ',atrim=0:' + n(len) + ',asetpts=PTS-STARTPTS,volume=' + b.gainDb + 'dB,' +
      'afade=t=in:st=0:d=' + n(b.fadeInSec) + ',afade=t=out:st=' + n(Math.max(0, len - b.fadeOutSec)) + ':d=' + n(b.fadeOutSec) + ',adelay=' + Math.round(b.start * 1000) + ':all=1[' + label + ']');
    return '[' + label + ']';
  });
  parts.push(bedLabels.length > 1 ? bedLabels.join('') + 'amix=inputs=' + bedLabels.length + ':normalize=0:duration=longest[music0]' : bedLabels[0] + 'anull[music0]');

  let cur = 'music0';
  sheet.drops.forEach((d, i) => {
    const expr = "if(between(t," + n(d.start) + "," + n(d.end) + "),1-" + (1 - sheet.levels.dropFloor) + "*min(1,min((t-" + n(d.start) + ")/0.2,(" + n(d.end) + "-t)/0.05)),1)";
    parts.push('[' + cur + "]volume=eval=frame:volume='" + expr + "'[mdrop" + i + ']');
    cur = 'mdrop' + i;
  });
  parts.push('[' + cur + '][sc]sidechaincompress=threshold=' + duckThreshold + ':ratio=' + duckRatio + ':attack=20:release=450[md]');

  const sfxLabels = [];
  for (const kind of Object.keys(inputs.sfx || {})) {
    const cues = sheet.sfx.filter(s => s.kind === kind);
    if (!cues.length) continue;
    const src = inputs.sfx[kind];
    const copies = cues.map((_, i) => 'c_' + kind + i);
    parts.push('[' + src.index + ':a]aresample=' + SR + (cues.length > 1 ? ',asplit=' + cues.length + copies.map(c => '[' + c + ']').join('') : '[' + copies[0] + ']'));
    cues.forEach((c, i) => {
      const out = 's_' + kind + i;
      parts.push('[' + copies[i] + ']volume=' + c.gainDb + 'dB,adelay=' + Math.round(c.t * 1000) + ':all=1[' + out + ']');
      sfxLabels.push('[' + out + ']');
    });
  }
  let sfxBus = null;
  if (sfxLabels.length) {
    parts.push(sfxLabels.join('') + 'amix=inputs=' + sfxLabels.length + ':normalize=0:duration=longest[sfxbus]');
    sfxBus = '[sfxbus]';
  }

  const final = ['[vo]', '[md]'];
  if (sfxBus) final.push(sfxBus);
  if (ambience) {
    parts.push('anoisesrc=d=' + n(sheet.durationSec) + ':c=brown:r=' + SR + ':a=0.2,lowpass=f=250,volume=' + sheet.ambience.gainDb + 'dB[amb]');
    final.push('[amb]');
  }
  parts.push(final.join('') + 'amix=inputs=' + final.length + ':normalize=0:duration=first,alimiter=limit=0.95[mix]');
  return { filter: parts.join(';'), outLabel: 'mix' };
}

module.exports = { buildMixGraph, SR };
