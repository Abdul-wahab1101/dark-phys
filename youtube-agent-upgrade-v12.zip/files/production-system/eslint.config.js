'use strict';
// Optional: only used if you install ESLint (npm i -D eslint). The built-in `npm run hygiene` needs nothing.
module.exports = [{
  files: ['**/*.js'],
  languageOptions: { ecmaVersion: 2022, sourceType: 'commonjs', globals: { require: 'readonly', module: 'writable', process: 'readonly', __dirname: 'readonly', Buffer: 'readonly', setTimeout: 'readonly', clearTimeout: 'readonly', setInterval: 'readonly', console: 'readonly' } },
  rules: { 'no-unused-vars': 'error', 'no-undef': 'error', 'no-empty': ['error', { allowEmptyCatch: false }], eqeqeq: 'error', 'prefer-const': 'error' }
}];
